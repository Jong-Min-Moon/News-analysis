import combined_training as ct

ct.do_crawl('연락사무소 폭파', '2020.06.18', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.19', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.20', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.21', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.22', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.23', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.24', initialize = False)
ct.do_crawl('연락사무소 폭파', '2020.06.25', initialize = False)