import combined_training as ct

ct.do_crawl('육군', '2020.08.09', initialize = True)