import combined_training as ct

ct.do_crawl('연락사무소 폭파', '2020.06.16', initialize = True)