

-- 헤드라인
SELECT * 
FROM (
	SELECT ROW_NUMBER ()
	OVER ( 
		PARTITION BY time
		ORDER BY n_comments DESC
		)
	RowNum, press, title, time
	FROM naver_news
	
	)
WHERE RowNum in (1,2)




--주요 댓글
SELECT * 
FROM (
	SELECT ROW_NUMBER ()
	OVER ( 
		PARTITION BY substr(time_written, 0, 11)
		ORDER BY like DESC
		)
	RowNum, title, like, re_reply, content, time_written, sent_score
	FROM naver_comment
	WHERE sent_score > 0
	)
WHERE RowNum in (1,2)


-- 댓글감성현황
SELECT substr(time_written, 0, 11) as time_writ, sum(sent_score>0) as pos, sum(sent_score<0) as neg, sum(sent_score=0) as neu, count(*) as total
FROM naver_comment
GROUP BY substr(time_written, 0, 11)




"DELETE FROM naver_comment WHERE time_written = '2020.08.15'"