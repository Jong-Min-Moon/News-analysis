import pandas as pd
import combined_training as ct

# ct.do_crawl('백선엽', '2020.07.16', initialize = True)
crawl_daterange_BSY = pd.date_range('2020.07.11', '2020.07.15')
for crawl_date_obj in crawl_daterange_BSY:
    ct.do_crawl('백선엽', crawl_date_obj.strftime('%Y.%m.%d'), initialize = False)
